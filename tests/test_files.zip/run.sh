if [ -f "good" ]; then
	echo "1:pass";
else
	echo "1:fail";
fi
